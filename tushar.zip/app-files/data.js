var APP_DATA = {
  "scenes": [
    {
      "id": "0-01",
      "name": "01",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1536,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.7938970630115714,
          "pitch": 0.10021812083435044,
          "rotation": 0,
          "target": "2-03"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-02",
      "name": "02",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1536,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.551457839162321,
          "pitch": 0.005502402815604768,
          "rotation": 0,
          "target": "2-03"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-03",
      "name": "03",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.5792347020487387,
          "pitch": 0.36733984288246546,
          "rotation": 6.283185307179586,
          "target": "0-01"
        },
        {
          "yaw": -1.2457950634029,
          "pitch": 0.30340944956194704,
          "rotation": 0,
          "target": "1-02"
        },
        {
          "yaw": -2.632028533085677,
          "pitch": 0.16738155171994507,
          "rotation": 0,
          "target": "3-04"
        },
        {
          "yaw": 1.8458321613112627,
          "pitch": 0.4028741198687875,
          "rotation": 0,
          "target": "4-05"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-04",
      "name": "04",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1536,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.2746407838768601,
          "pitch": 0.07481582944333631,
          "rotation": 0,
          "target": "2-03"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-05",
      "name": "05",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1536,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.4107618527474823,
          "pitch": 0.05233569420284745,
          "rotation": 0,
          "target": "2-03"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Tushar",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
